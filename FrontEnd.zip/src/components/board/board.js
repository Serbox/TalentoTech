import React from 'react'
import './board.css'

const board = () => {
  return (
    <>
        <div className='space'></div>
    </>
  )
}

export default board